FSL2Lua_do_sequences = 1
FSL2Lua_pilot = 2 -- This is optional. 1 = Captain, 2 = First Officer. See below how this option works

local FSL = require "FSL2Lua"

-- Open this site and press the key you want to bind to find its code:
-- https://keycode.info/ 


function afterLanding()
   FSL.PED_FLAP_LEVER("0")
   FSL.PED_ATCXPDR_MODE_Switch("STBY")
   FSL.OVHD_EXTLT_Strobe_Switch("OFF")
   FSL.OVHD_EXTLT_RwyTurnoff_Switch("OFF")
   FSL.OVHD_EXTLT_Land_L_Switch("RETR")
   FSL.OVHD_EXTLT_Land_R_Switch("RETR")
   FSL.OVHD_EXTLT_Nose_Switch("TAXI")
   FSL.PED_WXRadar_SYS_Switch("OFF")
   FSL.PED_WXRadar_PWS_Switch("OFF")
   --[[ -- because pilot was specified at the top of the file, the controls that are on his side
   (this only concerns the controls that are mirrored on each side, like the MCDUs)
   can be accessed directly from the 'FSL' table instead of 'FSL.FO' or 'FSL.CPT'.
   The other pilot's controls are in 'FSL.PF'
   ]]
   if not FSL.PF.GSLD_EFIS_FD_Button:isLit() then FSL.PF.GSLD_EFIS_FD_Button() end 
   if FSL.PF.GSLD_EFIS_LS_Button:isLit() then FSL.PF.GSLD_EFIS_LS_Button() end
   if FSL.bird() then FSL.GSLD_FCU_HDGTRKVSFPA_Button() end
   if FSL.GSLD_EFIS_LS_Button:isLit() then FSL.GSLD_EFIS_LS_Button() end
   if not FSL.GSLD_EFIS_FD_Button:isLit() then FSL.GSLD_EFIS_FD_Button() end
   if FSL.OVHD_AC_Pack_2_Button:isDown() then FSL.OVHD_AC_Pack_2_Button() end
   FSL:startTheApu()
end

function freezePassengers()
   FSL.OVHD_AC_Aft_Cabin_Knob(0)
   FSL.OVHD_AC_Fwd_Cabin_Knob(0)
end

keyBind(112,afterLanding) -- F1 key
keyBind(113,freezePassengers) -- F2 key