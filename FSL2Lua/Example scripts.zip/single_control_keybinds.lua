pilot = 1 -- 1 = Captain, 2 = First Oficer. Optional parameter, see below for usage example

local FSL = require "FSL2Lua"

-- Open this site and press the key you want to bind to find its code:
-- https://keycode.info/ 

-----------------------------------------------------------------------------------------

--[[ When defining a key bind, you can pass a condition function
as an optional argument. If you do that, the control will only be
executed if the condition is met (if the function returns true).
The example function below checks if you're in cockpit view (I need
that because these keys conflict with my EZCA key binds in outside view).]]

function cockpitView() return ipc.readUB(0x8320) == 2 end

keyBind(116,FSL.OVHD_EXTLT_Strobe_Switch_ON,cockpitView)
keyBind(45,FSL.OVHD_EXTLT_Strobe_Switch_AUTO,cockpitView)
keyBind(46,FSL.OVHD_EXTLT_Strobe_Switch_OFF,cockpitView)

keyBind(117,FSL.OVHD_EXTLT_Land_L_Switch_ON,cockpitView)
keyBind(36,FSL.OVHD_EXTLT_Land_L_Switch_OFF,cockpitView)
keyBind(35,FSL.OVHD_EXTLT_Land_L_Switch_RETR,cockpitView)

keyBind(117,FSL.OVHD_EXTLT_Land_R_Switch_ON,cockpitView)
keyBind(36,FSL.OVHD_EXTLT_Land_R_Switch_OFF,cockpitView)
keyBind(35,FSL.OVHD_EXTLT_Land_R_Switch_RETR,cockpitView)

keyBind(33,FSL.OVHD_EXTLT_Nose_Switch_TAXI,cockpitView)
keyBind(34,FSL.OVHD_EXTLT_Nose_Switch_OFF,cockpitView)

-----------------------------------------------------------------------------------------

keyBind(120,FSL.PED_WXRadar_SYS_Switch_1)
keyBind(121,FSL.PED_WXRadar_SYS_Switch_OFF)


keyBind(122,FSL.PED_WXRadar_PWS_Switch_OFF)
keyBind(123,FSL.PED_WXRadar_PWS_Switch_AUTO)

-----------------------------------------------------------------------------------------

keyBind(191,FSL.GSLD_Chrono_Button) -- same as FSL.CPT.GSLD_Chrono_Button because the Captain is specified as the pilot at the top of the script

keyBind(113,FSL.MIP_CHRONO_ELAPS_SEL_Switch_RUN)
keyBind(112,FSL.MIP_CHRONO_ELAPS_SEL_Switch_RST)